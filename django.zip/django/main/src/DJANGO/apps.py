 from django.apps import AppConfig


class ApiAppConfig(AppConfig):
    name = 'api_app'

